public class ReviewProject{
  /* --- Basic Java --- */

  /**
   * A person is tall enough for the ride if
   * they are at least 4.7 feet tall. Given a
   * height in feet, return whether the person
   * can get on the ride.
   */
  public static boolean checkHeight(double height){

  }

  /**
   * Given an int n: Return whether n is
   * a multiple of 5 or 12.
   */
  public static boolean div5or12(int n){

  }

  /**
   * Given two ints a,b: return true if
   * they share the same last two digits.
   */
  public static boolean shareLast2Digits(int a, int b){

  }

  /**
   * Given an int n: if n is between -100 and 100,
   * then return n multiplied by 100. Otherwise,
   * return n plus 100.
   */
  public static int distort(int n){

  }

  /**
   * Given two ints a,b: return true if
   * at least one of them is 9, or if
   * their sum is 9.
   * Return false otherwise.
   */
  public static boolean makes9(int a, int b){

  }

  /* --- Loops and Arrays --- */

  /**
   * Print all even numbers from 0 to n,
   * and then return how many even numbers were printed.
   */
  public static int countEvens(int n){

  }

  /**
   * Return the factorial of a number n.
   */
  public static int factorial(int n){

  }

  /**
   * Someone has a list of all the jellybeans in a jar.
   * Return how many jellybeans there are of my favorite flavor.
   */
  public static int countJellybeans(String[] jellybeans, String favorite){

  }

  /**
   * Given two arrays nums1 and nums2,
   * return a new array containing their 0th elements.
   * ex: [1,2,3], [2,3,4] => [1,2]
   * ex: [35,12,1], [9, 5] => [35, 9]
   */
  public static int[] combine(int[] nums1, int[] nums2){

  }

  /**
   * Return the sum of all the numbers in an array,
   * but if any two numbers are the same, then
   * they don't count toward the sum.
   * ex: [1,2,3,4] => 10
   * ex: [2,2,2,2] => 0
   * ex: [1,2,2,4] => 5
   */
  public static int getUniqueSum(int[] nums){

  }
}